open OUnit2
open Paccaml
open Levels
open State

let state_tests = List.flatten []

let command_tests = List.flatten []

let test_map1 = from_csv "data/map1.csv"

let test_map2 = from_csv "data/map2.csv"

let test_tile1 = get_tile test_map1 0

let test_pass_tile = get_tile test_map1 1

let test_next_tile name map tile direction exp =
  name >:: fun _ ->
  assert_equal
    (get_id (next_tile test_map1 (get_tile map tile) direction))
    exp

let levels_tests =
  [
    (*test tile 1 *)
    ( "test get_id/get_tile" >:: fun _ ->
      assert_equal (get_id test_tile1) 0 );
    ( "test passability/get_tile" >:: fun _ ->
      assert_equal (passibility test_tile1) false );
    ( "test\n      food/get_tile" >:: fun _ ->
      assert_equal (food test_tile1) 0 );
    (*test passible tile*)
    ( "test get_id/get_tile" >:: fun _ ->
      assert_equal (get_id test_pass_tile) 1 );
    ( "test passability/get_tile" >:: fun _ ->
      assert_equal (passibility test_pass_tile) true );
    ( "test food/get_tile" >:: fun _ ->
      assert_equal (food test_pass_tile) 1 );
    (*test next_tile*)
    test_next_tile "test South" test_map1 5 Up 25;
    test_next_tile "test North" test_map1 25 Down 5;
    test_next_tile "test East" test_map1 5 Right 6;
    test_next_tile "test West" test_map1 5 Left 4;
    ( "test num_cols" >:: fun _ ->
      assert_equal (get_numcols test_map1) 20 );
  ]

let ghosts_tests = List.flatten []

let suite =
  "test suite for A2"
  >::: List.flatten
         [ command_tests; state_tests; levels_tests; ghosts_tests ]

let _ = run_test_tt_main suite