open Graphics

(**[make_graph x y] makes a graph that is x wide and y tall*)
let make_graph (x : int) (y : int) =
  open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y)

let draw_poggers x y z =
  let color = rgb x y z in
  set_color color;
  draw_string "poggers";
  moveto 50 200;
  lineto 450 200;
  moveto 50 300;
  lineto 450 300

let draw_vague_map =
  try
    moveto 50 200;
    lineto 450 200;
    moveto 50 300;
    lineto 450 300
  with
  | _ -> ()
