open Csv
(**A level consists of a map filled with pathable tiles.*)

type tile_id = int

type tile = {
  id : tile_id;
  food : int;
  passible : bool;
}

let passibility tile = tile.passible

let food tile = tile.food

let get_id tile = tile.id

type map = {
  lst : tile list;
  (*assume maps are square for now*)
  num_cols : int;
}

let get_maplist map = map.lst

let get_numcols map = map.num_cols

exception UnknownTile of tile_id

let get_tile map tile_id =
  List.find (fun x -> get_id x = tile_id) (get_maplist map)

(*translates the csv (which outputs as a string list list), to a string
  list*)
let rec append_csv_list a =
  match a with
  | [] -> []
  | h :: t -> append_csv_list t @ h

(*given string list from append_csv, makes each of the tiles based on
  their passibility, incrememnt id*)
let rec build_map lst id_num =
  match lst with
  | [] -> []
  | h :: t ->
      {
        id = id_num;
        food = (if h = "1" then 1 else 0);
        passible = (if h = "1" then true else false);
      }
      :: build_map t (id_num + 1)

let from_csv file_name =
  let a = file_name |> load in
  { lst = build_map (append_csv_list a) 0; num_cols = Csv.columns a }

let next_tile map tile direction =
  let tile_id = get_id tile in
  let next_tile =
    if direction = Command.Up then
      if tile_id + map.num_cols < map.num_cols * map.num_cols then
        tile_id + map.num_cols
      else tile_id
    else if direction = Command.Down then
      if tile_id - map.num_cols >= 0 then tile_id - map.num_cols
      else tile_id
    else if direction = Command.Right then
      if tile_id + 1 < map.num_cols * map.num_cols then tile_id + 1
      else tile_id
    else if tile_id > 0 then tile_id - 1
    else tile_id
  in
  let a = get_tile map next_tile in
  if passibility a = false then tile else a

let try_direction map tile direction =
  try next_tile map tile direction with
  | UnknownTile _ -> { tile with id = -1 }
(*unknown tiles (which will be sorted out) are specifically tiles that
  do not exist. This might morph into tiles which arent passible, but
  that depends on further implementationj*)

let dir_list = [ Command.Up; Command.Down; Command.Right; Command.Left ]

let rec helper_neighbors map tile_id dir_list =
  match dir_list with
  | [] -> []
  | h :: t ->
      try_direction map tile_id h :: helper_neighbors map tile_id t

let neighbors map tile =
  List.filter
    (fun x -> get_id x != -1) (*sort out illegal tiles*)
    (helper_neighbors map tile dir_list)

let eat_tile tile = { tile with food = 0 }

let rec find_eat_tile tile = function
  | [] -> []
  | h :: t ->
      if get_id h = tile then eat_tile h :: find_eat_tile tile t
      else h :: find_eat_tile tile t

let eat_map map tile =
  {
    num_cols = map.num_cols;
    lst = find_eat_tile (get_id tile) (get_maplist map);
  }
