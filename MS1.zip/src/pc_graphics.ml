open Graphics
open Csv

let rec welcome_screen x y =
  open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y);
  set_color (rgb 194 178 128);
  fill_rect 0 0 x y;
  moveto ((size_x () / 2) - 110) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "Welcome to PacCaml!";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  draw_string "Press 'X' to continue";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 100);
  draw_string "use W,A,S,D controls";
  set_color (rgb 255 255 255);
  let x_press = wait_next_event [ Key_pressed ] in
  if x_press.keypressed = true then
    if x_press.key = 'x' then fill_rect 0 0 x y else welcome_screen x y
  else welcome_screen x y

let rec you_win_screen x y =
  (*open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y);*)
  set_color (rgb 194 178 128);
  fill_rect 0 0 x y;
  moveto ((size_x () / 2) - 110) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "You have won the game! Congratulations!";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 100);
  set_color (rgb 255 255 255);
  you_win_screen x y

let rec you_lose_screen x y =
  (* open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y);*)
  set_color (rgb 194 178 128);
  fill_rect 0 0 x y;
  moveto ((size_x () / 2) - 110) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string
    "You have lost the game :( Press x if you would like to play \
     again. ";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 100);
  set_color (rgb 255 255 255);
  you_lose_screen x y

let rec tile_builder (tilelist : Levels.tile list) id pix_size numcols =
  match tilelist with
  | [] -> ()
  | h :: t ->
      set_color (if Levels.passibility h = false then white else black);
      fill_rect
        (id mod numcols * pix_size)
        (id / numcols * pix_size)
        ((id mod numcols * pix_size) + pix_size)
        (((id / numcols) + 1) * pix_size);
      set_color green;
      if Levels.food h = 1 then (
        set_color green;
        fill_circle
          ((id mod numcols * pix_size) + (pix_size / 2))
          ((id / numcols * pix_size) + (pix_size / 2))
          2)
      else ();
      tile_builder t (id + 1) pix_size numcols

(*x and y should be the same for now. having it square is easy*)
let build_map tilelist numcols x =
  let pix_size = x / numcols in
  tile_builder tilelist 0 pix_size numcols

let pick_caml_colors input =
  if input = "-" then black
  else if input = "a" then white
  else if input = "b" then Graphics.rgb 255 121 0
  else if input = "c" then Graphics.rgb 196 98 16
  else Graphics.rgb 255 215 0

(*Convert csv char list list to color array list... will need to add
  more colors later*)
let rec find_color img =
  match img with
  | [] -> []
  | h :: t ->
      Array.of_list (List.map pick_caml_colors h) :: find_color t

let build_caml tile numcols x img =
  (*two notes on this function.

    1. depending on how many build functions like buildmap and buildcaml
    we write we might want to sabstract like the first part of this

    2. Images are loaded from csv file img*)
  let pix_size = x / numcols in
  let id = Levels.get_id tile in
  draw_image
    (make_image (Array.of_list (find_color (load img))))
    (id mod numcols * pix_size)
    (id / numcols * pix_size)
