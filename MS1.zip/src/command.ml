open Graphics

type orientation =
  | Up
  | Down
  | Left
  | Right

type command =
  | On of orientation
  | Off

let translate_move st =
  if st.keypressed then
    match st.key with
    | 'a' -> On Left
    | 'w' -> On Up
    | 's' -> On Down
    | 'd' -> On Right
    | _ -> Off
  else Off
