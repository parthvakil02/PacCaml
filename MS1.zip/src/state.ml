type pacState = {
  tile : Levels.tile;
  orientation : Command.orientation;
}

type t = {
  map : Levels.map;
  pacState : pacState;
  ghosts : Levels.tile list;
}

let current_tile st = st.pacState.tile

let current_direction st = st.pacState.orientation

let go cmd st =
  match cmd with
  | Command.On h ->
      {
        orientation = h;
        tile = Levels.next_tile st.map (current_tile st) h;
      }
  | Command.Off -> st.pacState

let eat_map_tile state = Levels.eat_map state.map state.pacState.tile
