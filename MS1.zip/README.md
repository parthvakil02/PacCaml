# PacCaml
To-dos:
1. PacCaml does not rotate when changing directions (make new images or rotate paccaml)
2. PacCaml can't scale in size and this is annoying when map_size changes
3. game glitches out when moving fast on larger maps. Implement arrays?
4. no win condition (i.e. eating all the tiles), or way to exit, i.e. q to quit 
5. there are like very few test cases
6. if a map is made that does not have boundaries on the edges, he can just walk through the sides of the map which is not ideal
7. starting tile for a map is completely arbitrary and we should probably fix that
<<<<<<< HEAD
(possibly first passible tile?)
8. still need ghost images
9. don't have any tests
10. Changing PacCaml orientation when he moves, and swapping between open and closed
mouth PacCaml
=======
8. still need ghost imeages
>>>>>>> 1da039123b942f0e3c06dec38fdd9357fdf64107

# Satisfactory
Implement ghosts
Finish on PacCaml moving
Add tests for all functions that need them
Fix specifications for functions in mli files

# Good
Eliminate PacCaml :( Lose the game 
Adding/calculate points based on eating

# Excellent
Animate Ghosts
Make PacCaml move continuously
Any other flavor we want to add

