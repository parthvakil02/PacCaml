open State

exception Empty

(*use for broken chasing paccaml stuff: go (match Ghosts.chase_paccaml
  st st.ghosts.python.tile with | [] -> raise Empty | h :: t -> h) st
  "pythongeist";*)

let update_state map_tuple next_tile st =
  {
    map = snd map_tuple;
    pacState = next_tile;
    ghosts =
      {
        java = go (Ghosts.random_ghost st "javarition") st "javarition";
        cpirit = go (Ghosts.random_ghost st "cpirit") st "cpirit";
        python =
          go (Ghosts.random_ghost st "pythongeist") st "pythongeist";
        sqhell = go (Ghosts.random_ghost st "sqhell") st "sqhell";
      };
    points =
      (if
       fst map_tuple
       && Levels.get_id next_tile.tile != Levels.get_id st.pacState.tile
      then st.points + 10
      else st.points);
    lives = st.lives;
  }

let init_state map points lives starttile startghosttile =
  {
    map;
    pacState =
      { tile = Levels.get_tile map starttile; orientation = Right };
    ghosts =
      {
        java =
          {
            tile = Levels.get_tile map startghosttile;
            orientation = Right;
          };
        python =
          {
            tile = Levels.get_tile map startghosttile;
            orientation = Up;
          };
        cpirit =
          {
            tile = Levels.get_tile map startghosttile;
            orientation = Left;
          };
        sqhell =
          {
            tile = Levels.get_tile map startghosttile;
            orientation = Down;
          };
      };
    points;
    lives;
  }

let die_state st starttile startghosttile =
  {
    map = st.map;
    pacState =
      { tile = Levels.get_tile st.map starttile; orientation = Right };
    ghosts =
      {
        java =
          {
            tile = Levels.get_tile st.map startghosttile;
            orientation = Right;
          };
        python =
          {
            tile = Levels.get_tile st.map startghosttile;
            orientation = Up;
          };
        cpirit =
          {
            tile = Levels.get_tile st.map startghosttile;
            orientation = Left;
          };
        sqhell =
          {
            tile = Levels.get_tile st.map startghosttile;
            orientation = Down;
          };
      };
    points = st.points;
    lives = st.lives - 1;
  }

(*fixes spamming issue by never letting a queue pile up*)

let rec resolve_queue dir =
  if Graphics.key_pressed () then
    let new_dir = Graphics.wait_next_event [ Key_pressed ] in
    resolve_queue new_dir
  else dir

let move_queue st queue =
  if Graphics.key_pressed () then
    let status = Graphics.wait_next_event [ Graphics.Key_pressed ] in
    let quit = status.key in
    let move_dir = Command.translate_move (resolve_queue status) in

    if move_dir = Command.Quit || quit = 'q' then (
      History.save st.points;
      exit 0)
    else if
      Levels.get_id (go move_dir st "caml").tile
      != Levels.get_id st.pacState.tile
    then (move_dir, move_dir)
    else (move_dir, On st.pacState.orientation)
  else if
    Levels.get_id (go queue st "caml").tile
    != Levels.get_id st.pacState.tile
  then (queue, queue)
  else (queue, On st.pacState.orientation)