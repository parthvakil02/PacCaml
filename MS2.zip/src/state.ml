open Graphics

type pacState = {
  tile : Levels.tile;
  orientation : Command.orientation;
}

type ghosts = {
  java : pacState;
  python : pacState;
  cpirit : pacState;
  sqhell : pacState;
}

type t = {
  map : Levels.map;
  pacState : pacState;
  ghosts : ghosts;
  points : int;
  lives : int;
}

let current_tile st pac =
  match pac with
  | "javarition" -> st.ghosts.java.tile
  | "pythongeist" -> st.ghosts.python.tile
  | "cpirit" -> st.ghosts.cpirit.tile
  | "sqhell" -> st.ghosts.sqhell.tile
  | _ -> st.pacState.tile

let current_direction st pac =
  match pac with
  | "javarition" -> st.ghosts.java.orientation
  | "pythongeist" -> st.ghosts.python.orientation
  | "cpirit" -> st.ghosts.cpirit.orientation
  | "sqhell" -> st.ghosts.sqhell.orientation
  | _ -> st.pacState.orientation

let go cmd st pac =
  match cmd with
  | Command.On h ->
      {
        orientation = h;
        tile = Levels.next_tile st.map (current_tile st pac) h;
      }
  | _ ->
      {
        orientation = current_direction st pac;
        tile = current_tile st pac;
      }

let eat_map_tile state tile = Levels.eat_map state.map tile

let check_collision st =
  Levels.get_id st.pacState.tile = Levels.get_id st.ghosts.java.tile
  || Levels.get_id st.pacState.tile
     = Levels.get_id st.ghosts.python.tile
  || Levels.get_id st.pacState.tile
     = Levels.get_id st.ghosts.cpirit.tile
  || Levels.get_id st.pacState.tile
     = Levels.get_id st.ghosts.sqhell.tile
