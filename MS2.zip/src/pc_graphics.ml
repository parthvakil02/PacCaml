open Graphics
open Csv

let write_points y margin =
  set_color (rgb 0 0 0);
  moveto 60 (y - margin + 65);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  draw_string "Points:";
  draw_rect (margin - 10)
    (y - margin + 55)
    (y - (2 * margin) + 10)
    (margin - 20);
  moveto (y - (3 * margin)) (y - margin + 65);
  draw_string "Lives:"

let update_points points y margin =
  set_color (Graphics.rgb 245 245 220);
  fill_rect 0 y y 50;
  set_color (rgb 0 0 0);
  moveto 140 (y - margin + 65);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  draw_string (Int.to_string points)

let update_lives lives y margin =
  set_color (rgb 0 0 0);
  moveto (y - 80) (y - margin + 65);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  draw_string (Int.to_string lives)

let rec welcome_screen life_points x y =
  open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y);
  set_color (rgb 194 178 128);
  fill_rect 0 0 x y;

  moveto ((size_x () / 2) - 110) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "Welcome to PacCaml!";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  draw_string "Press 'X' to continue";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 100);
  draw_string "use W,A,S,D controls";
  set_color (rgb 255 255 255);
  moveto ((size_x () / 2) - 100) ((size_y () / 2) - 150);
  draw_string "or press p to build a map";
  set_color (rgb 0 0 0);
  moveto
    ((size_x () / 2)
    - 70
    - (5 * String.length (string_of_int (fst life_points))))
    ((size_y () / 2) - 250);
  draw_string ("Lifetime Points: " ^ string_of_int (fst life_points));
  moveto
    ((size_x () / 2)
    - 50
    - (5 * String.length (string_of_int (snd life_points))))
    ((size_y () / 2) - 265);
  draw_string ("Highscore: " ^ string_of_int (snd life_points));

  set_color (rgb 255 255 255);
  let x_press = wait_next_event [ Key_pressed ] in
  if x_press.keypressed = true then
    if x_press.key = 'x' then fill_rect 0 0 x y
    else if x_press.key = 'q' then exit 0
    else if x_press.key = 'p' then Mapbuilder.main x y
    else welcome_screen life_points x y
  else welcome_screen life_points x y

let rec update_screen x y =
  open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y);
  set_color (rgb 194 178 128);
  fill_rect 0 0 x y;
  moveto ((size_x () / 2) - 150) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "Press 'X' to keep playing";
  moveto ((size_x () / 2) - 132) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  draw_string "Press 'q' to quit";
  moveto ((size_x () / 2) - 132) ((size_y () / 2) - 100);
  draw_string "Good Job!";
  set_color (rgb 255 255 255);
  let x_press = wait_next_event [ Key_pressed ] in
  if x_press.keypressed = true then
    if x_press.key = 'x' then (
      fill_rect 0 0 x y;
      true)
    else if x_press.key = 'q' then false
    else update_screen x y
  else update_screen x y

let rec you_win_screen x y =
  (*open_graph (" " ^ string_of_int x ^ "x" ^ string_of_int y);*)
  set_color (rgb 194 178 128);
  auto_synchronize false;
  fill_rect 0 0 x y;
  moveto 100 ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "You have won the game! Congratulations!";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 100);
  set_color (rgb 255 255 255);
  auto_synchronize true

let rec you_lose_screen x y =
  resize_window x y;
  set_color (rgb 194 178 128);
  auto_synchronize false;
  fill_rect 0 0 x y;
  moveto ((size_x () / 2) - 110) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "You have lost the game :( ";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 50);
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  moveto ((size_x () / 2) - 92) ((size_y () / 2) - 100);
  set_color (rgb 255 255 255);
  auto_synchronize true;
  let x_press = wait_next_event [ Key_pressed ] in
  if x_press.keypressed = true then ()

let rec death_screen x y =
  resize_window x y;
  set_color (rgb 194 178 128);
  auto_synchronize false;
  fill_rect 0 0 x y;
  moveto ((size_x () / 2) - 110) ((size_y () / 2) + 100);
  set_font "-sony-fixed-medium-r-normal--24-170-100-100-c-120-iso8859-1";
  set_color (rgb 0 0 0);
  draw_string "You have lost a life!";
  moveto ((size_x () / 2) - 250) ((size_y () / 2) - 50);
  draw_string "Press a key to continue playing!";
  set_font "-misc-fixed-bold-r-normal--15-140-75-75-c-90-iso8859-1";
  moveto ((size_x () / 2) - 140) ((size_y () / 2) - 100);
  set_color (rgb 255 255 255);
  auto_synchronize true;
  let x_press = wait_next_event [ Key_pressed ] in
  if x_press.keypressed = true then ()

let rec tile_builder tilelist id pix_size numcols =
  set_color
    (if Levels.passibility (Array.get tilelist id) = false then
     Graphics.rgb 245 245 220
    else black);
  fill_rect
    (id mod numcols * pix_size)
    (id / numcols * pix_size)
    ((id mod numcols * pix_size) + pix_size)
    (((id / numcols) + 1) * pix_size);
  set_color green;
  if Levels.food (Array.get tilelist id) = 1 then (
    set_color green;
    fill_circle
      ((id mod numcols * pix_size) + (pix_size / 2))
      ((id / numcols * pix_size) + (pix_size / 2))
      2)
  else ();
  if id < Array.length tilelist - 1 then
    tile_builder tilelist (id + 1) pix_size numcols
  else ()

(*x and y should be the same for now. having it square is easy*)
let build_map tilelist numcols x =
  let pix_size = x / numcols in
  tile_builder tilelist 0 pix_size numcols

let pick_caml_colors = function
  | "-" -> black
  | "a" -> white
  | "b" -> Graphics.rgb 255 121 0
  | "c" -> Graphics.rgb 196 98 16
  | _ -> Graphics.rgb 255 215 0

let pick_python_colors = function
  | "c" -> black
  | "-" -> white
  | "b" -> Graphics.rgb 54 124 194
  | "d" -> Graphics.rgb 255 230 0
  | "e" -> Graphics.rgb 161 208 255
  | "f" -> Graphics.rgb 199 171 72
  | _ -> Graphics.rgb 214 32 32

let pick_java_colors = function
  | "-" -> black
  | "b" -> white
  | "c" -> Graphics.rgb 123 179 242
  | "d" -> Graphics.rgb 201 201 201
  | _ -> Graphics.rgb 145 88 47

let pick_cpirit_colors = function
  | "-" -> black
  | "b" -> white
  | "c" -> Graphics.rgb 255 199 251
  | _ -> Graphics.rgb 214 214 214

let pick_sqhell_colors = function
  | "-" -> black
  | "b" -> Graphics.rgb 212 175 144
  | "c" -> Graphics.rgb 161 104 58
  | "d" -> Graphics.rgb 99 55 20
  | _ -> Graphics.rgb 194 52 52

(*Convert csv char list list to color array list... will need to add
  more colors later*)
let rec find_color img f =
  match img with
  | [] -> []
  | h :: t -> Array.of_list (List.map f h) :: find_color t f

let build_pac tile numcols x img schema =
  (*two notes on this function.

    1. depending on how many build functions like buildmap and buildcaml
    we write we might want to sabstract like the first part of this

    2. Images are loaded from csv file img*)
  let funct =
    match schema with
    | "javarition" -> pick_java_colors
    | "pythongeist" -> pick_python_colors
    | "cpirit" -> pick_cpirit_colors
    | "sqhell" -> pick_sqhell_colors
    | _ -> pick_caml_colors
  in
  let pix_size = x / numcols in
  let id = Levels.get_id tile in
  draw_image
    (make_image (Array.of_list (find_color (load img) funct)))
    (id mod numcols * pix_size)
    (id / numcols * pix_size)

let rec pac_image newdir olddir ctr =
  match (newdir, ctr) with
  | Command.On Left, 0 -> "data/Camls/Left1.csv"
  | Command.On Left, _ -> "data/Camls/Left2.csv"
  | Command.On Right, 0 -> "data/Camls/Right1.csv"
  | Command.On Right, _ -> "data/Camls/Right2.csv"
  | Command.On Up, 0 -> "data/Camls/Up1.csv"
  | Command.On Up, _ -> "data/Camls/Up2.csv"
  | Command.On Down, 0 -> "data/Camls/Down1.csv"
  | Command.On Down, _ -> "data/Camls/Down2.csv"
  | Command.Quit, _ -> pac_image olddir olddir ctr
  | Command.Off, x -> pac_image olddir olddir ctr

let rec ghost_image ctr ghost =
  let g_images =
    match ghost with
    | "javarition" ->
        ("data/Ghosts/javarition.csv", "data/Ghosts/javarition2.csv")
    | "pythongeist" ->
        ("data/Ghosts/pythongeist.csv", "data/Ghosts/pythongeist2.csv")
    | "cpirit" -> ("data/Ghosts/cpirit.csv", "data/Ghosts/cpirit2.csv")
    | "sqhell" -> ("data/Ghosts/sqhell.csv", "data/Ghosts/sqhell2.csv")
    | _ -> ("", "")
  in
  match ctr with
  | 0 -> fst g_images
  | _ -> snd g_images

let draw_sprites (st : State.t) x move queue ctr =
  auto_synchronize false;
  build_pac st.pacState.tile
    (Levels.get_numcols st.map)
    x
    (pac_image move queue (ctr mod 2))
    "caml";
  build_pac st.ghosts.java.tile
    (Levels.get_numcols st.map)
    x
    (ghost_image (ctr mod 2) "javarition")
    "javarition";
  build_pac st.ghosts.python.tile
    (Levels.get_numcols st.map)
    x
    (ghost_image (ctr mod 2) "pythongeist")
    "pythongeist";
  build_pac st.ghosts.cpirit.tile
    (Levels.get_numcols st.map)
    x
    (ghost_image (ctr mod 2) "cpirit")
    "cpirit";
  build_pac st.ghosts.sqhell.tile
    (Levels.get_numcols st.map)
    x
    (ghost_image (ctr mod 2) "sqhell")
    "sqhell";
  auto_synchronize true

let update_graphics (st : State.t) x =
  auto_synchronize false;
  build_map (Levels.get_maplist st.map) (Levels.get_numcols st.map) x;
  (*upgrade points has to precede write points for reasons*)
  update_points st.points x 50;
  write_points x 50;
  update_lives st.lives x 50;
  draw_rect 0 0 (x - 1) x;
  draw_rect 1 1 (x - 2) (x - 1);
  auto_synchronize true
