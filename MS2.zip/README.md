# PacCaml
To-dos:
1. there are still some untested modules
2. finish ghost algorithms
3. Finish decrement lives + die screen
4. Test if time breaks at 11:59:59 pm

# Satisfactory
1. Make more ghost decision algorithms
2. Choose map order of the game
4. Finish all test cases
5. Unhide things that can’t be tested because they’re hidden by graphics

# Good
1. Special food to eat ghosts, get bonus points
& New images for paccaml in special mode (ghosts too?)
3. New algorithms to make ghosts run away & kill ghosts
4. Users to play and test it
5. Test the game at 11:59

# Excellent
1. Music
2. Bonus/hidden level if you do specific steps
3. Perhaps create timer (If need more lines)


For Next Meeting:

Gillian

James

Parth

Stephanie

EVERYONE:
1. Fill our partner evaluation form
